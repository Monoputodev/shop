<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<meta name="template" content="greeny">
<meta name="title" content="greeny - Ecommerce Food Store HTML Template">
<meta name="keywords"
  content="organic, food, shop, ecommerce, store, html, bootstrap, template, agriculture, vegetables, products, farm, grocery, natural, online">
<title>Index Home - Xotil</title>
<link rel="icon" href="{{ asset('assets/web') }}/images/favicon.png">
<link rel="stylesheet" href="{{ asset('assets/web') }}/fonts/flaticon/flaticon.css">
<link rel="stylesheet" href="{{ asset('assets/web') }}/fonts/icofont/icofont.min.css">
<link rel="stylesheet" href="{{ asset('assets/web') }}/fonts/fontawesome/fontawesome.min.css">
<link rel="stylesheet" href="{{ asset('assets/web') }}/vendor/venobox/venobox.min.css">
<link rel="stylesheet" href="{{ asset('assets/web') }}/vendor/slickslider/slick.min.css">
<link rel="stylesheet" href="{{ asset('assets/web') }}/vendor/niceselect/nice-select.min.css">
<link rel="stylesheet" href="{{ asset('assets/web') }}/vendor/bootstrap/bootstrap.min.css">
<link rel="stylesheet" href="{{ asset('assets/web') }}/css/main.css">
<link rel="stylesheet" href="{{ asset('assets/web') }}/css/index.css">
<link rel="stylesheet" href="{{ asset('assets/web') }}/css/user-auth.css">
