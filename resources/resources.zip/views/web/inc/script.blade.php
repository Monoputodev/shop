
<script src="{{ asset('assets/web') }}/vendor/bootstrap/jquery-1.12.4.min.js"></script>
<script src="{{ asset('assets/web') }}/vendor/bootstrap/popper.min.js"></script>
<script src="{{ asset('assets/web') }}/vendor/bootstrap/bootstrap.min.js"></script>
<script src="{{ asset('assets/web') }}/vendor/countdown/countdown.min.js"></script>
<script src="{{ asset('assets/web') }}/vendor/niceselect/nice-select.min.js"></script>
<script src="{{ asset('assets/web') }}/vendor/slickslider/slick.min.js"></script>
<script src="{{ asset('assets/web') }}/vendor/venobox/venobox.min.js"></script>
<script src="{{ asset('assets/web') }}/js/nice-select.js"></script>
<script src="{{ asset('assets/web') }}/js/countdown.js"></script>
<script src="{{ asset('assets/web') }}/js/accordion.js"></script>
<script src="{{ asset('assets/web') }}/js/venobox.js"></script>
<script src="{{ asset('assets/web') }}/js/slick.js"></script>
<script src="{{ asset('assets/web') }}/js/main.js"></script>
@livewireScripts
