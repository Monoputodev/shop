<section class="section newitem-part">
    <div class="container">
        <div class="row">
            <div class="col">
                <div class="section-heading">
                    <h2>collected new items</h2>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col">
                <ul class="new-slider slider-arrow">
                    <li>
                        @include('web.component.product')
                    </li>
                    <li>
                        @include('web.component.product')
                    </li>
                    <li>
                        @include('web.component.product')
                    </li>
                    <li>
                        @include('web.component.product')
                    </li>
                    <li>
                        @include('web.component.product')
                    </li>
                </ul>
            </div>
        </div>
        <div class="row">
            <div class="col">
                <div class="section-btn-25"><a href="{{ asset('assets/web') }}/shop-4column.html"
                      class="btn btn-outline"><i class="fas fa-eye"></i><span>show more</span></a></div>
            </div>
        </div>
    </div>
</section>