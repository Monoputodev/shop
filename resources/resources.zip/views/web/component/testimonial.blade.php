<section class="section testimonial-part">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="section-heading">
                    <h2>client's feedback</h2>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <div class="testimonial-slider slider-arrow">
                    <div class="testimonial-card"><i class="fas fa-quote-left"></i>
                        <p>Lorem ipsum dolor consectetur adipisicing elit neque earum sapiente vitae obcaecati
                            magnam doloribus magni provident ipsam</p>
                        <h5>mahmud hasan</h5>
                        <ul>
                            <li class="fas fa-star"></li>
                            <li class="fas fa-star"></li>
                            <li class="fas fa-star"></li>
                            <li class="fas fa-star"></li>
                            <li class="fas fa-star"></li>
                        </ul><img src="{{ asset('assets/web') }}/images/avatar/01.jpg" alt="testimonial">
                    </div>
                    <div class="testimonial-card"><i class="fas fa-quote-left"></i>
                        <p>Lorem ipsum dolor consectetur adipisicing elit neque earum sapiente vitae obcaecati
                            magnam doloribus magni provident ipsam</p>
                        <h5>mahmud hasan</h5>
                        <ul>
                            <li class="fas fa-star"></li>
                            <li class="fas fa-star"></li>
                            <li class="fas fa-star"></li>
                            <li class="fas fa-star"></li>
                            <li class="fas fa-star"></li>
                        </ul><img src="{{ asset('assets/web') }}/images/avatar/02.jpg" alt="testimonial">
                    </div>
                    <div class="testimonial-card"><i class="fas fa-quote-left"></i>
                        <p>Lorem ipsum dolor consectetur adipisicing elit neque earum sapiente vitae obcaecati
                            magnam doloribus magni provident ipsam</p>
                        <h5>mahmud hasan</h5>
                        <ul>
                            <li class="fas fa-star"></li>
                            <li class="fas fa-star"></li>
                            <li class="fas fa-star"></li>
                            <li class="fas fa-star"></li>
                            <li class="fas fa-star"></li>
                        </ul><img src="{{ asset('assets/web') }}/images/avatar/03.jpg" alt="testimonial">
                    </div>
                    <div class="testimonial-card"><i class="fas fa-quote-left"></i>
                        <p>Lorem ipsum dolor consectetur adipisicing elit neque earum sapiente vitae obcaecati
                            magnam doloribus magni provident ipsam</p>
                        <h5>mahmud hasan</h5>
                        <ul>
                            <li class="fas fa-star"></li>
                            <li class="fas fa-star"></li>
                            <li class="fas fa-star"></li>
                            <li class="fas fa-star"></li>
                            <li class="fas fa-star"></li>
                        </ul><img src="{{ asset('assets/web') }}/images/avatar/04.jpg" alt="testimonial">
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
